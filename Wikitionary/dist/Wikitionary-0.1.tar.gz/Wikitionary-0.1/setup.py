from distutils.core import setup

setup(
    name = 'Wikitionary',
    version = '0.1',
    packages = ['wikitionary',],

long_description = open('README.txt').read(),
	)