#Scraps the wiki to get a one-line meaning of any term or phrase 				




#Sample code:

"""
import wikitionary as w

a = w.define('plankton')
print(a)
"""

#The output is a string which provides a meaning of 'plankton'.
